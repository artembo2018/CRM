-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Фев 04 2018 г., 13:21
-- Версия сервера: 5.7.19-17-beget-5.7.19-17-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `q77626bj_crm`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Фев 01 2018 г., 01:38
-- Последнее обновление: Фев 04 2018 г., 10:15
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(240) NOT NULL,
  `pwd` varchar(240) NOT NULL,
  `isAdmin` tinyint(4) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pwd`, `isAdmin`, `date`) VALUES
(2, 'artembo2020x', 'qwerty', 0, '2018-02-04 07:29:07'),
(3, 'admin', 'admin', 1, '2018-02-03 02:02:36'),
(6, 'artembox2019', 'цуцуекененг', 0, '2018-02-04 10:10:17'),
(8, 'demo', 'demo', 1, '2018-02-04 08:17:03'),
(9, 'artembo2019x', '123467', 0, '2018-02-04 10:15:51');

-- --------------------------------------------------------

--
-- Структура таблицы `users_reports`
--
-- Создание: Фев 04 2018 г., 09:00
-- Последнее обновление: Фев 04 2018 г., 10:16
--

DROP TABLE IF EXISTS `users_reports`;
CREATE TABLE `users_reports` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `month` varchar(16) NOT NULL,
  `day` int(11) NOT NULL,
  `hours` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_reports`
--

INSERT INTO `users_reports` (`id`, `user_id`, `month`, `day`, `hours`, `comment`) VALUES
(1, 2, 'Jan', 10, 23, 'eeererre'),
(2, 2, 'Feb', 3, 51, 'В нашей деревне написали это: \'Так, так и так!\'\nМы этому очень рады!\n\nцйццйц'),
(3, 3, 'Feb', 2, 12, 'Ooh! 12 hours for today'),
(7, 2, 'Feb', 2, 124, 'iou yiy89y8y8'),
(8, 2, 'Jan', 26, 1, 'qwerty - new hours! i i  iu iu ui yui y iy ui yui y iu yui y iuy ui yui ui y iuy ui yiu y ui yiu y iuy iu y iuy iu yi y i yiu y iuy iu yi uy i yi y i hiuyui yui y iu yui y uiyui y ui y iu yui yui y iuy iuy iu yiu y uiy iu yi uy iuy iu y iuy iu yiu y iu yi y iu y iuy i y iy  y i uy i yi y y i yi y i  y i y i yi yi yi yyiy iy iy i y i y yi  yi y i y iy i yi y iy i i y'),
(9, 2, 'Feb', 10, 8, 'class!!! - OK'),
(10, 3, 'Feb', 3, 0, ''),
(12, 2, 'Jan', 1, 12, 'My comment'),
(15, 6, 'Feb', 4, 14, 'j8998j u89h89h'),
(16, 2, 'Feb', 4, 57, '&lt;script&gt;alert(\'wewewe\');&lt;/script&gt;'),
(18, 2, 'Feb', 1, 8, 'Мой вам комментарий\n&lt;end&gt;'),
(19, 9, 'Feb', 4, 5, 'first hours');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `users_reports`
--
ALTER TABLE `users_reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`user_id`,`month`,`day`),
  ADD KEY `c_user_id` (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `users_reports`
--
ALTER TABLE `users_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `users_reports`
--
ALTER TABLE `users_reports`
  ADD CONSTRAINT `c_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
